const settings = {
 //___________ ┏  Penting Settings  ┓ ___________\\
 urladmin: 'https://t.me/SkyR4n',  // Isi dengan telegram yang digunakan
 adminId: ["1709137612"], // Isi dengan Id telegram yang digunakan
  // Ganti dengan token bot Telegram Anda
  telegramToken: '7446982198:AAEvN_oAvWn9LxDm5fr_mXitCjWLJzDJqWc',
};
module.exports = settings;